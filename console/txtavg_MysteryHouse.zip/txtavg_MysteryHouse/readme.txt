* TINY-MYSTERY HOUSE *

We developed a text adventure creation tool and got the classical masterpiece "Mystery House" ported.
This is technologically degenerate because I transplanted the world's first high-resolution graphic adventure as a text adventure.
Still, I think you can taste part of the essence of masterpiece.
We are glad if you can enjoy the simplicity and taste of the old adventure game.

* HOW TO PLAY *

Execute "cutehspcl txtavg.hs".

In the state waiting for key input, proceed with Enter key.

If there is a choice, enter the numerical value (1 to 9) and press the Enter key.

Enter "Q" and press Enter key to interrupt the game (Quit).

Enter "S" and press Enter key to save the progress of the game.

Enter "L" and press Enter key to resume game from the last save point.

* CREATED BY *

Cutie YAMADA

<EOF>
