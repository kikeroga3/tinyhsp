* txtavg2c *

This is a text adventure creation tool that works with CuteHSP console version.

* Contents of folder *

readme.txt	This manual
start.hs	Scenario execution program
enc_scn.hs	Scenario conversion program
open.txt	Scenario source text

* HOW TO USE *

1. Write a scenario in text format.

   Windows user: Please write with character code "SJIS".
   Other users : Please write with the character code "UTF-8".

2. Encrypt the text file with the scenario conversion program "enc_scn.hs".

   Run from the console as follows:

   cutehspcl enc_scn.hs

   Since the file name is asked, if the text file is "open.txt", press "open" and press Enter.
   Then an encrypted scenario file called "open.scn" is generated.

3. Execute "cutehspcl".

   When "cutehspcl" is executed, it reads "start.hs" automatically and executes it.
   And "start.hs" is executed, it first reads "open.scn".


* Scenario control command list *

There are nine commands.

@END
Write at the end of the scenario.

@INP
Enter key will be entered wait.
If you write the "@SEL" command before will accept selection number.

@RET
From the point where you jumped with "@JMP", "@SEL", "@IF"
It returns immediately after "@JMP", "@INP", "@IF".

@SEL label
Jump to label when selected from key input.
(label name specified without '*')

@JMP label
Jump to the label.
(label name specified without '*')

@FLG flag value
Set a value in the flag.

@IF flag value label
If the value of the flag is matched, it jumps to the label.
(label name specified without '*')

@RUN filename
Load a new scenario file and run.

*Label
To set a label.
Label name can be arbitrary name with '*' followed by alphanumeric characters.


Restriction specification.

  Up to 250 labels can be set in one file.
  There are 250 flags numbered 0 to 249.
  The value of the flag can be 0 to 79.
  Jump (@JMP) to return (@RET) is possible up to 10 nests.
   - When nesting is exceeded, the return position is discarded in ascending order.

* CREATED BY *

Cutie YAMADA

<EOF>
