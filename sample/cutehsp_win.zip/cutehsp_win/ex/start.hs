title "CuteHSP Extra"
pos 20,10
picload "tamarin.jpg"
font "tiny.ttf",48
pos 80,360
mes "Hello, World!?"
mes "文字と画像を表示します。"
pos 200,100
picload "cutehsp.png"
redraw 1
stop

