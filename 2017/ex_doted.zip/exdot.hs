;Extra Dot Character Draw

	;変数bf_chrにキャラクターデータを読込む
	sdim bf_chr,64000
	bload "chr2.bin",bf_chr		;"chr1～3.bin"のどれかを指定
	title "strsize="+strsize

	;画面クリア
	redraw 0 :color :boxf 0,0,640,480

	;キャラクターを画面にランダム表示
	repeat 20

		;p1=キャラクター番号
		;p2,p3=表示するX,Y座標
		;p4=1ドットのサイズ

		p1=cnt\4 :p2=rnd(640) :p3=rnd(480) :p4=5 :gosub *chrput
	loop

	redraw 1
	stop

;キャラクター表示ルーチン
*chrput
	p5=peek(bf_chr,0) :p6=p5*(p5/7) :p7=p1*(p6*2+8)

	;RGB色情報ゲット
	repeat 3
		p8=peek(bf_chr,p7+1+cnt)&63
		p_r(cnt)=80*(p8/16)+15 :p_g(cnt)=80*((p8&12)/4)+15 :p_b(cnt)=80*(p8&3)+15
	loop

	;ビット計算＆キャラクター表示
	p9=0
	repeat p6
		p_c1=peek(bf_chr,p7+4+cnt) :p_c2=peek(bf_chr,p7+4+p6+cnt)
		p8=64
		repeat 7
			p_x=p2-(p5*p4/2)+(p9\p5)*p4 :p_y=p3-(p5*p4/2)+(p9/p5)*p4
			p_cn=((p_c1&p8)>0)+2*((p_c2&p8)>0)
			if p_cn>0 {
				color p_r(p_cn-1),p_g(p_cn-1),p_b(p_cn-1)
				boxf p_x,p_y,p_x+p4-1,p_y+p4-1
			}
			p8=p8/2 :p9=p9+1
		loop
	loop
	return
